'use strict';

angular.module('confusionApp')

    .controller('MenuController', ['$scope', 'menuFactory', function($scope, menuFactory) {

        //Assignemnt step 5 - update for promotion thusly
        //old code =$scope.dishes= menuFactory.getDishes();
        //new code below
        $scope.tab = 1;
        $scope.filtText = '';
        $scope.showDetails = false;
        $scope.showMenu = false;
        $scope.message = "Loading ...";
        menuFactory.getDishes().query(
            function(response) {
                $scope.dishes = response;
                $scope.showMenu = true;
            },
            function(response) {
                $scope.message = "Error: " + response.status + " " + response.statusText;
            });
        //new code above

        $scope.select = function(setTab) {
            $scope.tab = setTab;

            if (setTab === 2) {
                $scope.filtText = "appetizer";
            } else if (setTab === 3) {
                $scope.filtText = "mains";
            } else if (setTab === 4) {
                $scope.filtText = "dessert";
            } else {
                $scope.filtText = "";
            }
        };

        $scope.isSelected = function(checkTab) {
            return ($scope.tab === checkTab);
        };

        $scope.toggleDetails = function() {
            $scope.showDetails = !$scope.showDetails;
        };
    }])

    .controller('ContactController', ['$scope', function($scope) {

        $scope.feedback = {
            mychannel: "",
            firstName: "",
            lastName: "",
            agree: false,
            email: ""
        };

        var channels = [{
            value: "tel",
            label: "Tel."
        }, {
            value: "Email",
            label: "Email"
        }];

        $scope.channels = channels;
        $scope.invalidChannelSelection = false;

    }])

    .controller('FeedbackController', ['$scope', function($scope) {

        $scope.sendFeedback = function() {

            console.log($scope.feedback);

            if ($scope.feedback.agree && ($scope.feedback.mychannel == "")) {
                $scope.invalidChannelSelection = true;
                console.log('incorrect');
            } else {
                $scope.invalidChannelSelection = false;
                $scope.feedback = {
                    mychannel: "",
                    firstName: "",
                    lastName: "",
                    agree: false,
                    email: ""
                };
                $scope.feedback.mychannel = "";
                $scope.feedbackForm.$setPristine();
                console.log($scope.feedback);
            }
        };
    }])

    .controller('DishDetailController', ['$scope', '$stateParams', 'menuFactory', function($scope, $stateParams, menuFactory) {

        $scope.showDish = false;
        $scope.message = "Loading ...";
        $scope.dish = menuFactory.getDishes().get({
                id: parseInt($stateParams.id, 10)
            })
            .$promise.then(
                function(response) {
                    $scope.dish = response;
                    $scope.showDish = true;
                },
                function(response) {
                    $scope.message = "Error: " + response.status + " " + response.statusText;
                }
            );

    }])
    //Assignment step 6 New code above

    .controller('DishCommentController', ['$scope', 'menuFactory', function($scope,menuFactory) {

        $scope.mycomment = {
            rating: 5,
            comment: "",
            author: "",
            date: ""
        };

        $scope.sendFeedback = function() {

            $scope.commentDate = new Date().toISOString();
            $scope.newcomment = {
                author: $scope.feedback.customerName,
                comment: $scope.feedback.comments,
                date: $scope.commentDate,
                rating: $scope.feedback.ratingradio
            };
            console.log($scope.newcomment);
            $scope.dish.comments.push($scope.newcomment);
            menuFactory.getDishes().update({id:$scope.dish.id},$scope.dish);
            console.log($scope.dish.comments);
//BELOW - don't know wat this code does but it breaks the form if it's commented out-----------------------
         if ($scope.feedback.agree && ($scope.feedback.mychannel == "") && !$scope.feedback.mychannel) {
                $scope.invalidChannelSelection = true;
                console.log('incorrect');
            } else {
                $scope.invalidChannelSelection = false;
                $scope.feedback = {
                    mychannel: "",
                    customerName: "",
                    lastName: "",
                    agree: false
                };
                $scope.feedback.mychannel = "";
//ABOVE - don't know wat this code does but it breaks the form if it's commented out-----------------------

                $scope.feedbackForm.$setPristine();
                //console.log($scope.feedback);
            }

            $scope.feedback = {
                ratingradio: 5
            };
        };
    }])

    // implement the IndexController and About Controller here
    .controller('IndexController', ['$scope', 'menuFactory', 'corporateFactory', function($scope, menuFactory, corporateFactory) {
        $scope.executiveChef = corporateFactory.getLeaders().get({id:3})
            .$promise.then(
            function(response){
                $scope.executiveChef = response;
                $scope.showExecutiveChef = true;
            },
            function(response) {
                $scope.message = "Error: "+response.status + " " + response.statusText;
                $scope.showExecutiveChef = false;                
            }
        );

        $scope.showDish = false;
        $scope.message="Loading ...";
        $scope.dish = menuFactory.getDishes().get({id:0})
        .$promise.then(
            function(response){
                $scope.dish = response;
                $scope.showDish = true;
            },
            function(response) {
                $scope.message = "Error: "+response.status + " " + response.statusText;
            }
        );
        
        $scope.featuredPromotion = menuFactory.getPromotion().get()
                .$promise.then(
                        function(response){
                            $scope.featuredPromotion = response;
                            $scope.showPromotion = true;
                        },
                        function(response) {
                            $scope.message = "Error: "+response.status + " " + response.statusText;
                        }
        );
    }])

    .controller('AboutController', ['$scope', 'corporateFactory', function($scope, corporateFactory) { 
        
        corporateFactory.getLeaders().query(
            function(response) {
                $scope.leaders = response;
                $scope.showLeaders = true;
            },
            function(response) {
                $scope.showLeaders = false;
                $scope.message = "Error: " + response.status + " " + response.statusText;
            });

    }]);

;