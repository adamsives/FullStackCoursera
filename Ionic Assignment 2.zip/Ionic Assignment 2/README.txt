ADAM SIVES
26052017

Partially complete Ionic Assignment 2
https://www.coursera.org/learn/hybrid-mobile-development/peer/lZdwI/ionic-modals-forms-popovers

Task 1 complete
Task 2 complete
Task 3 complete

Ideally needs a tidy before submission, but will submit as is, then tidy before next week's activity.


https://www.coursera.org/learn/hybrid-mobile-development/peer/lZdwI/ionic-modals-forms-popovers/submit
