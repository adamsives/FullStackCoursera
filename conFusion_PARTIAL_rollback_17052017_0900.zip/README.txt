ADAM SIVES
17 MAY 2017

**PARTIAL OF WHOLE PROJECT - FULL PROJECT WON'T UPLOAD FOR SOME REASON**

Starting point before
https://www.coursera.org/learn/angular-js/supplement/eGjax/exercise-instructions-client-server-communication-using-resource